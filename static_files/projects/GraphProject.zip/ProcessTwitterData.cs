﻿//using MoreLinq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TwitterDataTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string dataPath = @"C:\Data\IUSTDevCampData";

            var files = Directory.GetFiles(dataPath);

            var devCampFollowers = files.Select(f => Path.GetFileNameWithoutExtension(f));

            Console.WriteLine($"Total Devcamp follower count: {devCampFollowers.Count()}");

            var followerData = files.Select(
                f => (u: Path.GetFileNameWithoutExtension(f), followers: File.ReadAllLines(f).Skip(1)));

            var allfollowers = followerData.SelectMany(x => x.followers).Distinct();

            Console.WriteLine($"all follower count: {allfollowers.Count()}");

            var followerDict = followerData.ToDictionary(x => x.u, x => x.followers.ToHashSet());

            var extended = allfollowers.ToDictionary(x => x, y => new HashSet<string>());
                new Dictionary<string,HashSet<string>>();

            foreach (var follower in allfollowers)
            {
                followerDict.Where(x => x.Value.Contains(follower))
                    .ToList().ForEach(x => {if (!extended[follower].Contains(x.Key)) extended[follower].Add(x.Key); });
            }


            extended.OrderByDescending(x => x.Value.Count())
                    .ToList().ForEach(x => Console.WriteLine($"{x.Key}, {x.Value.Count}"));

        }
    }
}
