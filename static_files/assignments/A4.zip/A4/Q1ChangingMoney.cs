﻿using System;
using System.Collections.Generic;
using System.Text;
using TestCommon;

namespace A4
{
    public class Q1ChangingMoney : Processor
    {
        public Q1ChangingMoney(string testDataName) : base(testDataName)
        {}

        public override string Process(string inStr) =>
            TestTools.Process(inStr, (Func<long, long>) Solve);


        public virtual long Solve(long money)
        {
            var coins = new [] {10, 5, 1};
            long counts = 0;

            for (int i = 0; i < coins.Length; i++)
            {
                if (money == 0)
                    break;

                counts += (money / coins[i]);
                money %= coins[i];
            }

            return counts;
        }
    }
}
