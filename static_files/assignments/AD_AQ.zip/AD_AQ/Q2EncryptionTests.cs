﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace AQ.Tests
{
    [TestClass()]
    public class Q2EncryptionTests
    {
        [TestMethod()]
        public void SolveTest()
        {
            BigInteger n = 253;
            BigInteger e = 23;

            var result = Q2Encryption.Solve(n, e, "salam");

            CollectionAssert.AreEqual(new BigInteger[] {92, 212, 223, 212, 109}, result);
        }
    }
}