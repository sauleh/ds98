﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCommon;
using System.Numerics;

namespace AQ
{
    public class Q4Shor : Processor
    {
        public Q4Shor(string testDataName) : base(testDataName)
        {
        }

       public override string Process(string inStr) =>
       TestTools.Process(inStr, (Func<BigInteger, BigInteger[]>)Solve);

        public BigInteger[] Solve(BigInteger n)
        {
            // write your code here
            throw new NotImplementedException();
        }
    }
}
