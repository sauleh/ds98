﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCommon;
using System.Numerics;

namespace AQ
{
    public class Q5Decipher : Processor
    {
        public Q5Decipher(string testDataName) : base(testDataName)
        {
        }

        public override string Process(string inStr) =>
            TestTools.ProcessQ(inStr, (Func<BigInteger, BigInteger, BigInteger[], string>)Solve);

        public string Solve(BigInteger n, BigInteger e, BigInteger[] cipher)
        {
            // write your code here
            throw new NotImplementedException();
        }
    }
}
