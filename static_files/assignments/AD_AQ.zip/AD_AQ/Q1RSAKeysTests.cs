﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace AQ.Tests
{
    [TestClass()]
    public class Q1RSAKeysTests
    {
        [TestMethod()]
        public void SolveTest()
        {
            BigInteger p = 9973;
            BigInteger q = 9949;
            BigInteger e = 23;

            var result = Q1RSAKeys.Solve(p, q, e);

            Assert.AreEqual(103, result);
        }
    }
}