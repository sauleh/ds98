﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCommon;
using System.Numerics;
using ManualRsa;

namespace AQ
{
    public class Q1RSAKeys
    { 
        public static BigInteger Solve(BigInteger p, BigInteger q, BigInteger e)
        {
            RSA rsa = new RSA();
            rsa.p = p;
            rsa.q = q;
            rsa.e = e;

            rsa.CalculateNumbers();
            return rsa.d;

            // write your code here
            throw new NotImplementedException();
        }
    }
}
