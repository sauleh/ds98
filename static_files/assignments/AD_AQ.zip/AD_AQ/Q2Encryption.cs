﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCommon;
using System.Numerics;

namespace AQ
{
    public class Q2Encryption 
    {
        public static BigInteger[] Solve(BigInteger n, BigInteger e, string plain)
        {
            // write your code here
            throw new NotImplementedException();
        }
    }
}
