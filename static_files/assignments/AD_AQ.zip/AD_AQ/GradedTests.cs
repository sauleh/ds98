﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using AQ;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestCommon;

namespace AQ.Tests
{
    [DeploymentItem("TestData", "AQ_TestData")]
    [TestClass()]
    public class GradedTests
    {     
        [TestMethod(), Timeout(4000)]
        public void SolveTest_Q3Factorize()
        {
            RunTest(new Q3Factorize("TD4"));
        }

        [TestMethod(), Timeout(4000)]
        public void SolveTest_Q4Shor()
        {
            RunTest(new Q4Shor("TD4"));
        }

        [TestMethod(), Timeout(4000)]
        public void SolveTest_Q5Decipher()
        {
            RunTest(new Q5Decipher("TD4"));
        }

        public static void RunTest(Processor p)
        {
            TestTools.RunLocalTest("AQ", p.Process, p.TestDataName, p.Verifier, VerifyResultWithoutOrder: p.VerifyResultWithoutOrder,
                excludedTestCases: p.ExcludedTestCases);
        }
    }
}